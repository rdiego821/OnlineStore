/* Search the related match for a word in a previous list */
(function () {
    this.Search = this.Search || {};
    var ns = this.Search;
   
    ns.SearchMatch = function (value) {
        alert(value);
    }

	
}());
