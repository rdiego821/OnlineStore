/* IndexedDB functions */
(function () {
    this.IndexedDB = this.IndexedDB || {};
    var ns = this.IndexedDB;
	
	var dataBase = null;
   
    ns.CreateDB = function () {
		var indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;   
		dataBase = indexedDB.open("OnlineStore", 1);
		console.log("DB created...");
		
		dataBase.onupgradeneeded = function (e) {
			var active = dataBase.result;
			var object = active.createObjectStore("BrandsClothing", { keyPath : 'id', autoIncrement : true });
			object.createIndex('by_name', 'name', { unique : false });
			object.createIndex('by_type', 'type', { unique : false });
			object.createIndex('by_id', 'id', { unique : true });
		};

		dataBase.onsuccess = function (e) {
			console.log('DB loaded succesfully');
		};

		dataBase.onerror = function (e)  {
			console.log('Error during loading DB');
		};
				
    }
	
	ns.Add = function(){
		var active = dataBase.result;
		var data = active.transaction(['BrandsClothing'], "readwrite");
		var object = data.objectStore('BrandsClothing');
		
		var request = object.put({
			id: document.querySelector('#id').value,
			name: document.querySelector('#name').value,
			type: document.querySelector('#type').value
		});
		
		request.onerror = function(e){
			console.log(request.error.name + '\n\n' + request.error.message);
		}
		
		data.oncomplete = function(e){
			document.querySelector('#id').value = '';
			document.querySelector('#name').value = '';
			document.querySelector('#type').value = '';
			console.log("Object successfully added");
		}
	}

	
}());